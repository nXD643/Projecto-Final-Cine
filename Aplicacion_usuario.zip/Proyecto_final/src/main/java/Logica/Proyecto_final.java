package Logica;

import java.util.ArrayList;
import java.sql.*;
import java.time.LocalDate;

public class Proyecto_final {
    public static void main(String[] args) {
        
        LocalDate fecha = LocalDate.of(2026, 10, 20);
        
        LocalDate fecha2 = LocalDate.of(1990, 2, 1);
        
        System.out.println(fecha);
        
        Date date = Date.valueOf(fecha2);
        
        System.out.println(date);
        
        LocalDate fechita = date.toLocalDate();
        
        System.out.println(fechita);
        
        // El atributo duracion pelicula queda como string modificar clases, der y er y UML
    }
}